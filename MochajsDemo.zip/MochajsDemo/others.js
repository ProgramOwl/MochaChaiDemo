module.exports = {
	say3: function(){
		return '3';
	},
	num3: function(){
		return 3;
	},
};